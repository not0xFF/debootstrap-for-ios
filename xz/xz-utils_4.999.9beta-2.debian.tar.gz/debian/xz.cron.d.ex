#
# Regular cron jobs for the xz package
#
0 4	* * *	root	[ -x /usr/bin/xz_maintenance ] && /usr/bin/xz_maintenance
